<!-- 来源: api_reference\fileio\options.html -->

[![Logo](../../_static/images/keysight_logo.svg)](http://www.keysight.com/)

* [keysight-pwdatatools](../../index.md)
* [API Reference](../index.md)
* [File I/O](index.md)
* File IO Options

0.11.0

*invert\_colors* Theme

*rate\_review* Feedback
[*code* Source](../../_sources/api_reference/fileio/options.rst.txt)

*help\_center* Help

[Contact Keysight](https://www.keysight.com/in/en/contact.html)

About

*menu* Contents

Table of contents

*close*

* [Initial Setup](../../initial_setup/index.md)
  + [Installation](../../initial_setup/installation.md)
  + [Dependencies](../../initial_setup/dependencies.md)
* [Core Concepts](../../core_concepts/index.md)
  + [All About Filepaths](../../core_concepts/all_about_filepaths.md)
  + [File Extensions and Formats](../../core_concepts/file_exts_and_formats.md)
  + [Multi-Dimensional Data](../../core_concepts/multi_dimensional_data.md)
  + [pandas DataFrame Indexing](../../core_concepts/pandas_dataframe_indexing.md)
* [How To](../../howto/index.md)
  + [Read a File](../../howto/read_a_file.md)
  + [Write a File](../../howto/write_a_file.md)
  + [Translate a File](../../howto/translate_a_file.md)
  + [Use the Var Class](../../howto/use_var_class.md)
  + [Use the Block Class](../../howto/use_block_class.md)
  + [Use the Group Class](../../howto/use_group_class.md)
  + [Work with ADS Data](../../howto/work_with_ADS_data.md)
  + [Work with CSV Data](../../howto/work_with_csv_data.md)
  + [Work with Load Pull Data](../../howto/work_with_loadpull_data.md)
  + [Work with SystemVue Data](../../howto/work_with_SystemVue_data.md)
  + [Show or Hide Log Messages](../../howto/show_or_hide_messages.md)
  + [Get the Data Tools Version](../../howto/get_the_version.md)
  + [Use the New Data Tools Version](../../howto/use_new_version.md)
* [Examples](../../examples/index.md)
  + [Load Pull Examples](../../examples/loadpull/index.md)
    - [Swept Gamma](../../examples/loadpull/swept_gamma_example.md)
    - [Swept Gamma and Power](../../examples/loadpull/swept_gamma_power_example.md)
    - [Swept Frequency, Gamma, and Power](../../examples/loadpull/swept_freq_gamma_power_example.md)
    - [Focus lpcwave file](../../examples/loadpull/focus_lpcwave.md)
* [API Reference](../index.md)
  + [Main](../main/index.md)
    - [Var](../main/var/index.md)
      * [keysight.pwdatatools.Var.attrs](../main/var/_autosummary/keysight.pwdatatools.Var.attrs.md)
      * [keysight.pwdatatools.Var.block](../main/var/_autosummary/keysight.pwdatatools.Var.block.md)
      * [keysight.pwdatatools.Var.kind](../main/var/_autosummary/keysight.pwdatatools.Var.kind.md)
      * [keysight.pwdatatools.Var.dims](../main/var/_autosummary/keysight.pwdatatools.Var.dims.md)
      * [keysight.pwdatatools.Var.dtype](../main/var/_autosummary/keysight.pwdatatools.Var.dtype.md)
      * [keysight.pwdatatools.Var.name](../main/var/_autosummary/keysight.pwdatatools.Var.name.md)
      * [keysight.pwdatatools.Var.ndim](../main/var/_autosummary/keysight.pwdatatools.Var.ndim.md)
      * [keysight.pwdatatools.Var.role](../main/var/_autosummary/keysight.pwdatatools.Var.role.md)
      * [keysight.pwdatatools.Var.shape](../main/var/_autosummary/keysight.pwdatatools.Var.shape.md)
      * [keysight.pwdatatools.Var.size](../main/var/_autosummary/keysight.pwdatatools.Var.size.md)
      * [keysight.pwdatatools.Var.unit](../main/var/_autosummary/keysight.pwdatatools.Var.unit.md)
      * [keysight.pwdatatools.Var.\_\_array\_\_](../main/var/_autosummary/keysight.pwdatatools.Var.__array__.md)
      * [keysight.pwdatatools.Var.\_\_array\_ufunc\_\_](../main/var/_autosummary/keysight.pwdatatools.Var.__array_ufunc__.md)
      * [keysight.pwdatatools.Var.\_\_call\_\_](../main/var/_autosummary/keysight.pwdatatools.Var.__call__.md)
      * [keysight.pwdatatools.Var.\_\_getitem\_\_](../main/var/_autosummary/keysight.pwdatatools.Var.__getitem__.md)
      * [keysight.pwdatatools.Var.\_\_init\_\_](../main/var/_autosummary/keysight.pwdatatools.Var.__init__.md)
      * [keysight.pwdatatools.Var.\_\_iter\_\_](../main/var/_autosummary/keysight.pwdatatools.Var.__iter__.md)
      * [keysight.pwdatatools.Var.\_\_len\_\_](../main/var/_autosummary/keysight.pwdatatools.Var.__len__.md)
      * [keysight.pwdatatools.Var.\_\_repr\_\_](../main/var/_autosummary/keysight.pwdatatools.Var.__repr__.md)
      * [keysight.pwdatatools.Var.\_\_repr\_short\_\_](../main/var/_autosummary/keysight.pwdatatools.Var.__repr_short__.md)
      * [keysight.pwdatatools.Var.copy](../main/var/_autosummary/keysight.pwdatatools.Var.copy.md)
      * [keysight.pwdatatools.Var.copy\_metadata\_in\_place](../main/var/_autosummary/keysight.pwdatatools.Var.copy_metadata_in_place.md)
      * [keysight.pwdatatools.Var.count\_observations](../main/var/_autosummary/keysight.pwdatatools.Var.count_observations.md)
      * [keysight.pwdatatools.Var.drop\_observations](../main/var/_autosummary/keysight.pwdatatools.Var.drop_observations.md)
      * [keysight.pwdatatools.Var.fill\_nan](../main/var/_autosummary/keysight.pwdatatools.Var.fill_nan.md)
      * [keysight.pwdatatools.Var.fill\_null](../main/var/_autosummary/keysight.pwdatatools.Var.fill_null.md)
      * [keysight.pwdatatools.Var.has\_empty\_dims](../main/var/_autosummary/keysight.pwdatatools.Var.has_empty_dims.md)
      * [keysight.pwdatatools.Var.has\_role](../main/var/_autosummary/keysight.pwdatatools.Var.has_role.md)
      * [keysight.pwdatatools.Var.info](../main/var/_autosummary/keysight.pwdatatools.Var.info.md)
      * [keysight.pwdatatools.Var.is\_nan](../main/var/_autosummary/keysight.pwdatatools.Var.is_nan.md)
      * [keysight.pwdatatools.Var.is\_null](../main/var/_autosummary/keysight.pwdatatools.Var.is_null.md)
      * [keysight.pwdatatools.Var.keep\_observations](../main/var/_autosummary/keysight.pwdatatools.Var.keep_observations.md)
      * [keysight.pwdatatools.Var.repeat\_observations](../main/var/_autosummary/keysight.pwdatatools.Var.repeat_observations.md)
      * [keysight.pwdatatools.Var.rename](../main/var/_autosummary/keysight.pwdatatools.Var.rename.md)
      * [keysight.pwdatatools.Var.replace](../main/var/_autosummary/keysight.pwdatatools.Var.replace.md)
      * [keysight.pwdatatools.Var.select](../main/var/_autosummary/keysight.pwdatatools.Var.select.md)
      * [keysight.pwdatatools.Var.set\_data\_in\_place](../main/var/_autosummary/keysight.pwdatatools.Var.set_data_in_place.md)
      * [keysight.pwdatatools.Var.sort\_observations](../main/var/_autosummary/keysight.pwdatatools.Var.sort_observations.md)
      * [keysight.pwdatatools.Var.to\_numpy\_maskedarray](../main/var/_autosummary/keysight.pwdatatools.Var.to_numpy_maskedarray.md)
      * [keysight.pwdatatools.Var.to\_numpy\_ndarray](../main/var/_autosummary/keysight.pwdatatools.Var.to_numpy_ndarray.md)
      * [keysight.pwdatatools.Var.to\_pandas\_dataframe](../main/var/_autosummary/keysight.pwdatatools.Var.to_pandas_dataframe.md)
      * [keysight.pwdatatools.Var.to\_pandas\_series](../main/var/_autosummary/keysight.pwdatatools.Var.to_pandas_series.md)
      * [keysight.pwdatatools.Var.from\_1D\_vars](../main/var/_autosummary/keysight.pwdatatools.Var.from_1D_vars.md)
      * [keysight.pwdatatools.Var.from\_pandas\_dataframe](../main/var/_autosummary/keysight.pwdatatools.Var.from_pandas_dataframe.md)
      * [keysight.pwdatatools.Var.from\_pandas\_series](../main/var/_autosummary/keysight.pwdatatools.Var.from_pandas_series.md)
    - [Block](../main/block/index.md)
      * [keysight.pwdatatools.Block.attrs](../main/block/_autosummary/keysight.pwdatatools.Block.attrs.md)
      * [keysight.pwdatatools.Block.dvarnames](../main/block/_autosummary/keysight.pwdatatools.Block.dvarnames.md)
      * [keysight.pwdatatools.Block.exprs](../main/block/_autosummary/keysight.pwdatatools.Block.exprs.md)
      * [keysight.pwdatatools.Block.idxnames](../main/block/_autosummary/keysight.pwdatatools.Block.idxnames.md)
      * [keysight.pwdatatools.Block.ivarnames](../main/block/_autosummary/keysight.pwdatatools.Block.ivarnames.md)
      * [keysight.pwdatatools.Block.name](../main/block/_autosummary/keysight.pwdatatools.Block.name.md)
      * [keysight.pwdatatools.Block.varnames](../main/block/_autosummary/keysight.pwdatatools.Block.varnames.md)
      * [keysight.pwdatatools.Block.\_\_contains\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__contains__.md)
      * [keysight.pwdatatools.Block.\_\_delitem\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__delitem__.md)
      * [keysight.pwdatatools.Block.\_\_eq\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__eq__.md)
      * [keysight.pwdatatools.Block.\_\_getitem\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__getitem__.md)
      * [keysight.pwdatatools.Block.\_\_init\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__init__.md)
      * [keysight.pwdatatools.Block.\_\_iter\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__iter__.md)
      * [keysight.pwdatatools.Block.\_\_len\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__len__.md)
      * [keysight.pwdatatools.Block.\_\_repr\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__repr__.md)
      * [keysight.pwdatatools.Block.\_\_repr\_short\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__repr_short__.md)
      * [keysight.pwdatatools.Block.\_\_setitem\_\_](../main/block/_autosummary/keysight.pwdatatools.Block.__setitem__.md)
      * [keysight.pwdatatools.Block.clear](../main/block/_autosummary/keysight.pwdatatools.Block.clear.md)
      * [keysight.pwdatatools.Block.copy](../main/block/_autosummary/keysight.pwdatatools.Block.copy.md)
      * [keysight.pwdatatools.Block.count\_observations](../main/block/_autosummary/keysight.pwdatatools.Block.count_observations.md)
      * [keysight.pwdatatools.Block.crucial\_varnames](../main/block/_autosummary/keysight.pwdatatools.Block.crucial_varnames.md)
      * [keysight.pwdatatools.Block.drop\_observations](../main/block/_autosummary/keysight.pwdatatools.Block.drop_observations.md)
      * [keysight.pwdatatools.Block.drop\_vars](../main/block/_autosummary/keysight.pwdatatools.Block.drop_vars.md)
      * [keysight.pwdatatools.Block.drop\_vars\_in\_place](../main/block/_autosummary/keysight.pwdatatools.Block.drop_vars_in_place.md)
      * [keysight.pwdatatools.Block.expr\_as\_numpy\_ndarray](../main/block/_autosummary/keysight.pwdatatools.Block.expr_as_numpy_ndarray.md)
      * [keysight.pwdatatools.Block.fill\_nan](../main/block/_autosummary/keysight.pwdatatools.Block.fill_nan.md)
      * [keysight.pwdatatools.Block.fill\_null](../main/block/_autosummary/keysight.pwdatatools.Block.fill_null.md)
      * [keysight.pwdatatools.Block.get](../main/block/_autosummary/keysight.pwdatatools.Block.get.md)
      * [keysight.pwdatatools.Block.get\_var](../main/block/_autosummary/keysight.pwdatatools.Block.get_var.md)
      * [keysight.pwdatatools.Block.get\_var\_as\_expr](../main/block/_autosummary/keysight.pwdatatools.Block.get_var_as_expr.md)
      * [keysight.pwdatatools.Block.info](../main/block/_autosummary/keysight.pwdatatools.Block.info.md)
      * [keysight.pwdatatools.Block.is\_block](../main/block/_autosummary/keysight.pwdatatools.Block.is_block.md)
      * [keysight.pwdatatools.Block.is\_group](../main/block/_autosummary/keysight.pwdatatools.Block.is_group.md)
      * [keysight.pwdatatools.Block.items](../main/block/_autosummary/keysight.pwdatatools.Block.items.md)
      * [keysight.pwdatatools.Block.iter\_sections](../main/block/_autosummary/keysight.pwdatatools.Block.iter_sections.md)
      * [keysight.pwdatatools.Block.iter\_vars](../main/block/_autosummary/keysight.pwdatatools.Block.iter_vars.md)
      * [keysight.pwdatatools.Block.keep\_observations](../main/block/_autosummary/keysight.pwdatatools.Block.keep_observations.md)
      * [keysight.pwdatatools.Block.keep\_vars](../main/block/_autosummary/keysight.pwdatatools.Block.keep_vars.md)
      * [keysight.pwdatatools.Block.keep\_vars\_in\_place](../main/block/_autosummary/keysight.pwdatatools.Block.keep_vars_in_place.md)
      * [keysight.pwdatatools.Block.keys](../main/block/_autosummary/keysight.pwdatatools.Block.keys.md)
      * [keysight.pwdatatools.Block.pop](../main/block/_autosummary/keysight.pwdatatools.Block.pop.md)
      * [keysight.pwdatatools.Block.rename\_vars](../main/block/_autosummary/keysight.pwdatatools.Block.rename_vars.md)
      * [keysight.pwdatatools.Block.rename\_vars\_in\_place](../main/block/_autosummary/keysight.pwdatatools.Block.rename_vars_in_place.md)
      * [keysight.pwdatatools.Block.set\_data](../main/block/_autosummary/keysight.pwdatatools.Block.set_data.md)
      * [keysight.pwdatatools.Block.set\_data\_in\_place](../main/block/_autosummary/keysight.pwdatatools.Block.set_data_in_place.md)
      * [keysight.pwdatatools.Block.set\_vars\_in\_place](../main/block/_autosummary/keysight.pwdatatools.Block.set_vars_in_place.md)
      * [keysight.pwdatatools.Block.sort\_observations](../main/block/_autosummary/keysight.pwdatatools.Block.sort_observations.md)
      * [keysight.pwdatatools.Block.sort\_observations\_by](../main/block/_autosummary/keysight.pwdatatools.Block.sort_observations_by.md)
      * [keysight.pwdatatools.Block.to\_pandas\_dataframe](../main/block/_autosummary/keysight.pwdatatools.Block.to_pandas_dataframe.md)
      * [keysight.pwdatatools.Block.to\_file](../main/block/_autosummary/keysight.pwdatatools.Block.to_file.md)
      * [keysight.pwdatatools.Block.update](../main/block/_autosummary/keysight.pwdatatools.Block.update.md)
      * [keysight.pwdatatools.Block.values](../main/block/_autosummary/keysight.pwdatatools.Block.values.md)
      * [keysight.pwdatatools.Block.with\_idxs](../main/block/_autosummary/keysight.pwdatatools.Block.with_idxs.md)
      * [keysight.pwdatatools.Block.from\_file](../main/block/_autosummary/keysight.pwdatatools.Block.from_file.md)
      * [keysight.pwdatatools.Block.from\_pandas\_dataframe](../main/block/_autosummary/keysight.pwdatatools.Block.from_pandas_dataframe.md)
    - [Group](../main/group/index.md)
      * [keysight.pwdatatools.Group.attrs](../main/group/_autosummary/keysight.pwdatatools.Group.attrs.md)
      * [keysight.pwdatatools.Group.members](../main/group/_autosummary/keysight.pwdatatools.Group.members.md)
      * [keysight.pwdatatools.Group.name](../main/group/_autosummary/keysight.pwdatatools.Group.name.md)
      * [keysight.pwdatatools.Group.\_\_add\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__add__.md)
      * [keysight.pwdatatools.Group.\_\_contains\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__contains__.md)
      * [keysight.pwdatatools.Group.\_\_delitem\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__delitem__.md)
      * [keysight.pwdatatools.Group.\_\_eq\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__eq__.md)
      * [keysight.pwdatatools.Group.\_\_getitem\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__getitem__.md)
      * [keysight.pwdatatools.Group.\_\_iadd\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__iadd__.md)
      * [keysight.pwdatatools.Group.\_\_init\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__init__.md)
      * [keysight.pwdatatools.Group.\_\_iter\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__iter__.md)
      * [keysight.pwdatatools.Group.\_\_len\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__len__.md)
      * [keysight.pwdatatools.Group.\_\_repr\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__repr__.md)
      * [keysight.pwdatatools.Group.\_\_repr\_short\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__repr_short__.md)
      * [keysight.pwdatatools.Group.\_\_setitem\_\_](../main/group/_autosummary/keysight.pwdatatools.Group.__setitem__.md)
      * [keysight.pwdatatools.Group.append](../main/group/_autosummary/keysight.pwdatatools.Group.append.md)
      * [keysight.pwdatatools.Group.clear](../main/group/_autosummary/keysight.pwdatatools.Group.clear.md)
      * [keysight.pwdatatools.Group.copy](../main/group/_autosummary/keysight.pwdatatools.Group.copy.md)
      * [keysight.pwdatatools.Group.count](../main/group/_autosummary/keysight.pwdatatools.Group.count.md)
      * [keysight.pwdatatools.Group.extend](../main/group/_autosummary/keysight.pwdatatools.Group.extend.md)
      * [keysight.pwdatatools.Group.fill\_membernames](../main/group/_autosummary/keysight.pwdatatools.Group.fill_membernames.md)
      * [keysight.pwdatatools.Group.filled\_membernames](../main/group/_autosummary/keysight.pwdatatools.Group.filled_membernames.md)
      * [keysight.pwdatatools.Group.flatten](../main/group/_autosummary/keysight.pwdatatools.Group.flatten.md)
      * [keysight.pwdatatools.Group.flattened](../main/group/_autosummary/keysight.pwdatatools.Group.flattened.md)
      * [keysight.pwdatatools.Group.get\_member\_as\_block](../main/group/_autosummary/keysight.pwdatatools.Group.get_member_as_block.md)
      * [keysight.pwdatatools.Group.get\_member\_as\_group](../main/group/_autosummary/keysight.pwdatatools.Group.get_member_as_group.md)
      * [keysight.pwdatatools.Group.get\_member\_as\_loadpullblock](../main/group/_autosummary/keysight.pwdatatools.Group.get_member_as_loadpullblock.md)
      * [keysight.pwdatatools.Group.index](../main/group/_autosummary/keysight.pwdatatools.Group.index.md)
      * [keysight.pwdatatools.Group.insert](../main/group/_autosummary/keysight.pwdatatools.Group.insert.md)
      * [keysight.pwdatatools.Group.is\_block](../main/group/_autosummary/keysight.pwdatatools.Group.is_block.md)
      * [keysight.pwdatatools.Group.is\_group](../main/group/_autosummary/keysight.pwdatatools.Group.is_group.md)
      * [keysight.pwdatatools.Group.iter\_blocks](../main/group/_autosummary/keysight.pwdatatools.Group.iter_blocks.md)
      * [keysight.pwdatatools.Group.iter\_members](../main/group/_autosummary/keysight.pwdatatools.Group.iter_members.md)
      * [keysight.pwdatatools.Group.pop](../main/group/_autosummary/keysight.pwdatatools.Group.pop.md)
      * [keysight.pwdatatools.Group.remove](../main/group/_autosummary/keysight.pwdatatools.Group.remove.md)
      * [keysight.pwdatatools.Group.reverse](../main/group/_autosummary/keysight.pwdatatools.Group.reverse.md)
      * [keysight.pwdatatools.Group.to\_file](../main/group/_autosummary/keysight.pwdatatools.Group.to_file.md)
      * [keysight.pwdatatools.Group.tree](../main/group/_autosummary/keysight.pwdatatools.Group.tree.md)
      * [keysight.pwdatatools.Group.from\_file](../main/group/_autosummary/keysight.pwdatatools.Group.from_file.md)
  + [Metadata](../metadata/index.md)
    - [AttrsDict](../metadata/attrsdict/index.md)
      * [keysight.pwdatatools.AttrsDict.key\_type](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.key_type.md)
      * [keysight.pwdatatools.AttrsDict.reserved\_keys](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.reserved_keys.md)
      * [keysight.pwdatatools.AttrsDict.value\_types](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.value_types.md)
      * [keysight.pwdatatools.AttrsDict.\_\_contains\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__contains__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_delitem\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__delitem__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_eq\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__eq__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_getitem\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__getitem__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_init\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__init__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_iter\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__iter__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_len\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__len__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_ne\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__ne__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_repr\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__repr__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_repr\_short\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__repr_short__.md)
      * [keysight.pwdatatools.AttrsDict.\_\_setitem\_\_](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.__setitem__.md)
      * [keysight.pwdatatools.AttrsDict.clear](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.clear.md)
      * [keysight.pwdatatools.AttrsDict.copy](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.copy.md)
      * [keysight.pwdatatools.AttrsDict.get](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.get.md)
      * [keysight.pwdatatools.AttrsDict.items](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.items.md)
      * [keysight.pwdatatools.AttrsDict.keys](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.keys.md)
      * [keysight.pwdatatools.AttrsDict.pop](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.pop.md)
      * [keysight.pwdatatools.AttrsDict.popitem](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.popitem.md)
      * [keysight.pwdatatools.AttrsDict.setdefault](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.setdefault.md)
      * [keysight.pwdatatools.AttrsDict.to\_builtins](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.to_builtins.md)
      * [keysight.pwdatatools.AttrsDict.update](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.update.md)
      * [keysight.pwdatatools.AttrsDict.values](../metadata/attrsdict/_autosummary/keysight.pwdatatools.AttrsDict.values.md)
    - [Dims](../metadata/dims/index.md)
      * [keysight.pwdatatools.Dims.ndim](../metadata/dims/_autosummary/keysight.pwdatatools.Dims.ndim.md)
      * [keysight.pwdatatools.Dims.\_\_bool\_\_](../metadata/dims/_autosummary/keysight.pwdatatools.Dims.__bool__.md)
      * [keysight.pwdatatools.Dims.\_\_eq\_\_](../metadata/dims/_autosummary/keysight.pwdatatools.Dims.__eq__.md)
      * [keysight.pwdatatools.Dims.\_\_init\_\_](../metadata/dims/_autosummary/keysight.pwdatatools.Dims.__init__.md)
      * [keysight.pwdatatools.Dims.\_\_repr\_\_](../metadata/dims/_autosummary/keysight.pwdatatools.Dims.__repr__.md)
      * [keysight.pwdatatools.Dims.\_\_repr\_short\_\_](../metadata/dims/_autosummary/keysight.pwdatatools.Dims.__repr_short__.md)
      * [keysight.pwdatatools.Dims.copy](../metadata/dims/_autosummary/keysight.pwdatatools.Dims.copy.md)
      * [keysight.pwdatatools.Dims.is\_empty](../metadata/dims/_autosummary/keysight.pwdatatools.Dims.is_empty.md)
      * [keysight.pwdatatools.Dims.replace](../metadata/dims/_autosummary/keysight.pwdatatools.Dims.replace.md)
  + [File I/O](index.md)
    - [DataFile](datafile/index.md)
      * [keysight.pwdatatools.DataFile.folder](datafile/_autosummary/keysight.pwdatatools.DataFile.folder.md)
      * [keysight.pwdatatools.DataFile.format\_override](datafile/_autosummary/keysight.pwdatatools.DataFile.format_override.md)
      * [keysight.pwdatatools.DataFile.ext](datafile/_autosummary/keysight.pwdatatools.DataFile.ext.md)
      * [keysight.pwdatatools.DataFile.name](datafile/_autosummary/keysight.pwdatatools.DataFile.name.md)
      * [keysight.pwdatatools.DataFile.path](datafile/_autosummary/keysight.pwdatatools.DataFile.path.md)
      * [keysight.pwdatatools.DataFile.stem](datafile/_autosummary/keysight.pwdatatools.DataFile.stem.md)
      * [keysight.pwdatatools.DataFile.suffix](datafile/_autosummary/keysight.pwdatatools.DataFile.suffix.md)
      * [keysight.pwdatatools.DataFile.\_\_init\_\_](datafile/_autosummary/keysight.pwdatatools.DataFile.__init__.md)
      * [keysight.pwdatatools.DataFile.\_\_repr\_\_](datafile/_autosummary/keysight.pwdatatools.DataFile.__repr__.md)
      * [keysight.pwdatatools.DataFile.copy](datafile/_autosummary/keysight.pwdatatools.DataFile.copy.md)
      * [keysight.pwdatatools.DataFile.delete](datafile/_autosummary/keysight.pwdatatools.DataFile.delete.md)
      * [keysight.pwdatatools.DataFile.exists](datafile/_autosummary/keysight.pwdatatools.DataFile.exists.md)
      * [keysight.pwdatatools.DataFile.find\_diffs](datafile/_autosummary/keysight.pwdatatools.DataFile.find_diffs.md)
      * [keysight.pwdatatools.DataFile.get\_format](datafile/_autosummary/keysight.pwdatatools.DataFile.get_format.md)
      * [keysight.pwdatatools.DataFile.has\_format](datafile/_autosummary/keysight.pwdatatools.DataFile.has_format.md)
      * [keysight.pwdatatools.DataFile.has\_modtime\_match](datafile/_autosummary/keysight.pwdatatools.DataFile.has_modtime_match.md)
      * [keysight.pwdatatools.DataFile.is\_ads](datafile/_autosummary/keysight.pwdatatools.DataFile.is_ads.md)
      * [keysight.pwdatatools.DataFile.is\_citi](datafile/_autosummary/keysight.pwdatatools.DataFile.is_citi.md)
      * [keysight.pwdatatools.DataFile.is\_farfieldio](datafile/_autosummary/keysight.pwdatatools.DataFile.is_farfieldio.md)
      * [keysight.pwdatatools.DataFile.is\_hfss\_ffd](datafile/_autosummary/keysight.pwdatatools.DataFile.is_hfss_ffd.md)
      * [keysight.pwdatatools.DataFile.is\_loadpull](datafile/_autosummary/keysight.pwdatatools.DataFile.is_loadpull.md)
      * [keysight.pwdatatools.DataFile.is\_mdif](datafile/_autosummary/keysight.pwdatatools.DataFile.is_mdif.md)
      * [keysight.pwdatatools.DataFile.is\_mdm](datafile/_autosummary/keysight.pwdatatools.DataFile.is_mdm.md)
      * [keysight.pwdatatools.DataFile.is\_native](datafile/_autosummary/keysight.pwdatatools.DataFile.is_native.md)
      * [keysight.pwdatatools.DataFile.is\_s2pmdif](datafile/_autosummary/keysight.pwdatatools.DataFile.is_s2pmdif.md)
      * [keysight.pwdatatools.DataFile.is\_same](datafile/_autosummary/keysight.pwdatatools.DataFile.is_same.md)
      * [keysight.pwdatatools.DataFile.is\_smatrixio](datafile/_autosummary/keysight.pwdatatools.DataFile.is_smatrixio.md)
      * [keysight.pwdatatools.DataFile.is\_touchstone](datafile/_autosummary/keysight.pwdatatools.DataFile.is_touchstone.md)
      * [keysight.pwdatatools.DataFile.lines](datafile/_autosummary/keysight.pwdatatools.DataFile.lines.md)
      * [keysight.pwdatatools.DataFile.modtime](datafile/_autosummary/keysight.pwdatatools.DataFile.modtime.md)
      * [keysight.pwdatatools.DataFile.modtime\_datetime](datafile/_autosummary/keysight.pwdatatools.DataFile.modtime_datetime.md)
      * [keysight.pwdatatools.DataFile.read\_as\_block](datafile/_autosummary/keysight.pwdatatools.DataFile.read_as_block.md)
      * [keysight.pwdatatools.DataFile.read\_as\_group](datafile/_autosummary/keysight.pwdatatools.DataFile.read_as_group.md)
      * [keysight.pwdatatools.DataFile.read\_as\_loadpullblock](datafile/_autosummary/keysight.pwdatatools.DataFile.read_as_loadpullblock.md)
      * [keysight.pwdatatools.DataFile.remove](datafile/_autosummary/keysight.pwdatatools.DataFile.remove.md)
      * [keysight.pwdatatools.DataFile.set\_modtime](datafile/_autosummary/keysight.pwdatatools.DataFile.set_modtime.md)
      * [keysight.pwdatatools.DataFile.translate](datafile/_autosummary/keysight.pwdatatools.DataFile.translate.md)
      * [keysight.pwdatatools.DataFile.tree](datafile/_autosummary/keysight.pwdatatools.DataFile.tree.md)
    - [read\_file\_as\_block](read_file_as_block.md)
    - [read\_file\_as\_group](read_file_as_group.md)
    - [read\_file\_as\_loadpullblock](read_file_as_loadpullblock.md)
    - [read\_file](read_file.md)
    - [translate\_file](translate_file.md)
    - [write\_file](write_file.md)
    - File IO Options
    - [File IO Options Defaults](defaults.md)
  + [Load Pull](../loadpull/index.md)
    - [LoadPullBlock](../loadpull/loadpullblock/index.md)
      * [keysight.pwdatatools.LoadPullBlock.attrs](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.attrs.md)
      * [keysight.pwdatatools.LoadPullBlock.dvarnames](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.dvarnames.md)
      * [keysight.pwdatatools.LoadPullBlock.exprs](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.exprs.md)
      * [keysight.pwdatatools.LoadPullBlock.gamma\_idxname](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.gamma_idxname.md)
      * [keysight.pwdatatools.LoadPullBlock.gamma\_ivarname](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.gamma_ivarname.md)
      * [keysight.pwdatatools.LoadPullBlock.idxnames](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.idxnames.md)
      * [keysight.pwdatatools.LoadPullBlock.ivarnames](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.ivarnames.md)
      * [keysight.pwdatatools.LoadPullBlock.name](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.name.md)
      * [keysight.pwdatatools.LoadPullBlock.outer\_idxnames](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.outer_idxnames.md)
      * [keysight.pwdatatools.LoadPullBlock.outer\_ivarnames](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.outer_ivarnames.md)
      * [keysight.pwdatatools.LoadPullBlock.power\_idxname](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.power_idxname.md)
      * [keysight.pwdatatools.LoadPullBlock.power\_ivarname](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.power_ivarname.md)
      * [keysight.pwdatatools.LoadPullBlock.varnames](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.varnames.md)
      * [keysight.pwdatatools.LoadPullBlock.z\_idxname](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.z_idxname.md)
      * [keysight.pwdatatools.LoadPullBlock.z\_ivarname](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.z_ivarname.md)
      * [keysight.pwdatatools.LoadPullBlock.\_\_contains\_\_](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.__contains__.md)
      * [keysight.pwdatatools.LoadPullBlock.\_\_delitem\_\_](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.__delitem__.md)
      * [keysight.pwdatatools.LoadPullBlock.\_\_getitem\_\_](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.__getitem__.md)
      * [keysight.pwdatatools.LoadPullBlock.\_\_init\_\_](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.__init__.md)
      * [keysight.pwdatatools.LoadPullBlock.\_\_iter\_\_](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.__iter__.md)
      * [keysight.pwdatatools.LoadPullBlock.\_\_len\_\_](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.__len__.md)
      * [keysight.pwdatatools.LoadPullBlock.\_\_repr\_\_](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.__repr__.md)
      * [keysight.pwdatatools.LoadPullBlock.\_\_repr\_short\_\_](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.__repr_short__.md)
      * [keysight.pwdatatools.LoadPullBlock.\_\_setitem\_\_](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.__setitem__.md)
      * [keysight.pwdatatools.LoadPullBlock.at\_gcomp](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.at_gcomp.md)
      * [keysight.pwdatatools.LoadPullBlock.at\_power](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.at_power.md)
      * [keysight.pwdatatools.LoadPullBlock.contourplot](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.contourplot.md)
      * [keysight.pwdatatools.LoadPullBlock.coord\_system](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.coord_system.md)
      * [keysight.pwdatatools.LoadPullBlock.copy](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.copy.md)
      * [keysight.pwdatatools.LoadPullBlock.count\_observations](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.count_observations.md)
      * [keysight.pwdatatools.LoadPullBlock.crucial\_varnames](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.crucial_varnames.md)
      * [keysight.pwdatatools.LoadPullBlock.drop\_invalid\_regular](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.drop_invalid_regular.md)
      * [keysight.pwdatatools.LoadPullBlock.drop\_observations](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.drop_observations.md)
      * [keysight.pwdatatools.LoadPullBlock.drop\_grid\_edges](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.drop_grid_edges.md)
      * [keysight.pwdatatools.LoadPullBlock.drop\_vars](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.drop_vars.md)
      * [keysight.pwdatatools.LoadPullBlock.drop\_vars\_in\_place](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.drop_vars_in_place.md)
      * [keysight.pwdatatools.LoadPullBlock.expr\_as\_numpy\_ndarray](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.expr_as_numpy_ndarray.md)
      * [keysight.pwdatatools.LoadPullBlock.fill\_nan](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.fill_nan.md)
      * [keysight.pwdatatools.LoadPullBlock.fill\_null](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.fill_null.md)
      * [keysight.pwdatatools.LoadPullBlock.gamma\_idx](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.gamma_idx.md)
      * [keysight.pwdatatools.LoadPullBlock.gamma\_ivar](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.gamma_ivar.md)
      * [keysight.pwdatatools.LoadPullBlock.gamma\_ivar\_scatterplot](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.gamma_ivar_scatterplot.md)
      * [keysight.pwdatatools.LoadPullBlock.gamma\_to\_z](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.gamma_to_z.md)
      * [keysight.pwdatatools.LoadPullBlock.get](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.get.md)
      * [keysight.pwdatatools.LoadPullBlock.get\_grid](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.get_grid.md)
      * [keysight.pwdatatools.LoadPullBlock.get\_sweep](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.get_sweep.md)
      * [keysight.pwdatatools.LoadPullBlock.get\_var](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.get_var.md)
      * [keysight.pwdatatools.LoadPullBlock.get\_var\_as\_expr](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.get_var_as_expr.md)
      * [keysight.pwdatatools.LoadPullBlock.grid\_data](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.grid_data.md)
      * [keysight.pwdatatools.LoadPullBlock.has\_gamma\_sweep](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.has_gamma_sweep.md)
      * [keysight.pwdatatools.LoadPullBlock.has\_power\_sweep](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.has_power_sweep.md)
      * [keysight.pwdatatools.LoadPullBlock.has\_outer\_sweep](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.has_outer_sweep.md)
      * [keysight.pwdatatools.LoadPullBlock.has\_regular\_power\_ivar](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.has_regular_power_ivar.md)
      * [keysight.pwdatatools.LoadPullBlock.has\_z\_sweep](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.has_z_sweep.md)
      * [keysight.pwdatatools.LoadPullBlock.info](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.info.md)
      * [keysight.pwdatatools.LoadPullBlock.is\_block](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.is_block.md)
      * [keysight.pwdatatools.LoadPullBlock.is\_group](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.is_group.md)
      * [keysight.pwdatatools.LoadPullBlock.items](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.items.md)
      * [keysight.pwdatatools.LoadPullBlock.iter\_sections](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.iter_sections.md)
      * [keysight.pwdatatools.LoadPullBlock.iter\_vars](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.iter_vars.md)
      * [keysight.pwdatatools.LoadPullBlock.is\_gridded](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.is_gridded.md)
      * [keysight.pwdatatools.LoadPullBlock.keep\_observations](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.keep_observations.md)
      * [keysight.pwdatatools.LoadPullBlock.keep\_vars](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.keep_vars.md)
      * [keysight.pwdatatools.LoadPullBlock.keep\_vars\_in\_place](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.keep_vars_in_place.md)
      * [keysight.pwdatatools.LoadPullBlock.keys](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.keys.md)
      * [keysight.pwdatatools.LoadPullBlock.pop](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.pop.md)
      * [keysight.pwdatatools.LoadPullBlock.power\_idx](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.power_idx.md)
      * [keysight.pwdatatools.LoadPullBlock.power\_ivar](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.power_ivar.md)
      * [keysight.pwdatatools.LoadPullBlock.regularize\_power\_ivar](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.regularize_power_ivar.md)
      * [keysight.pwdatatools.LoadPullBlock.rename\_vars](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.rename_vars.md)
      * [keysight.pwdatatools.LoadPullBlock.rename\_vars\_in\_place](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.rename_vars_in_place.md)
      * [keysight.pwdatatools.LoadPullBlock.set\_data](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.set_data.md)
      * [keysight.pwdatatools.LoadPullBlock.set\_data\_in\_place](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.set_data_in_place.md)
      * [keysight.pwdatatools.LoadPullBlock.set\_vars\_in\_place](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.set_vars_in_place.md)
      * [keysight.pwdatatools.LoadPullBlock.set\_zrefload\_role](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.set_zrefload_role.md)
      * [keysight.pwdatatools.LoadPullBlock.sort\_observations](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.sort_observations.md)
      * [keysight.pwdatatools.LoadPullBlock.sort\_observations\_by](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.sort_observations_by.md)
      * [keysight.pwdatatools.LoadPullBlock.to\_adscontourblock](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.to_adscontourblock.md)
      * [keysight.pwdatatools.LoadPullBlock.to\_pandas\_dataframe](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.to_pandas_dataframe.md)
      * [keysight.pwdatatools.LoadPullBlock.to\_file](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.to_file.md)
      * [keysight.pwdatatools.LoadPullBlock.tricontourplot](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.tricontourplot.md)
      * [keysight.pwdatatools.LoadPullBlock.update](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.update.md)
      * [keysight.pwdatatools.LoadPullBlock.values](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.values.md)
      * [keysight.pwdatatools.LoadPullBlock.with\_idxs](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.with_idxs.md)
      * [keysight.pwdatatools.LoadPullBlock.z\_ivar](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.z_ivar.md)
      * [keysight.pwdatatools.LoadPullBlock.zrefload](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.zrefload.md)
      * [keysight.pwdatatools.LoadPullBlock.z\_to\_gamma](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.z_to_gamma.md)
      * [keysight.pwdatatools.LoadPullBlock.from\_block](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.from_block.md)
      * [keysight.pwdatatools.LoadPullBlock.from\_file](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.from_file.md)
      * [keysight.pwdatatools.LoadPullBlock.from\_pandas\_dataframe](../loadpull/loadpullblock/_autosummary/keysight.pwdatatools.LoadPullBlock.from_pandas_dataframe.md)
    - [LoadPullSweep](../loadpull/loadpullsweep/index.md)
      * [keysight.pwdatatools.LoadPullSweep.idxnames](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.idxnames.md)
      * [keysight.pwdatatools.LoadPullSweep.idxnames\_map](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.idxnames_map.md)
      * [keysight.pwdatatools.LoadPullSweep.ivarnames](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.ivarnames.md)
      * [keysight.pwdatatools.LoadPullSweep.gamma\_idxname](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.gamma_idxname.md)
      * [keysight.pwdatatools.LoadPullSweep.gamma\_ivarname](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.gamma_ivarname.md)
      * [keysight.pwdatatools.LoadPullSweep.gamma\_or\_z\_idxname](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.gamma_or_z_idxname.md)
      * [keysight.pwdatatools.LoadPullSweep.gamma\_or\_z\_ivarname](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.gamma_or_z_ivarname.md)
      * [keysight.pwdatatools.LoadPullSweep.outer\_idxnames](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.outer_idxnames.md)
      * [keysight.pwdatatools.LoadPullSweep.outer\_ivarnames](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.outer_ivarnames.md)
      * [keysight.pwdatatools.LoadPullSweep.power\_idxname](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.power_idxname.md)
      * [keysight.pwdatatools.LoadPullSweep.power\_ivarname](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.power_ivarname.md)
      * [keysight.pwdatatools.LoadPullSweep.z\_idxname](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.z_idxname.md)
      * [keysight.pwdatatools.LoadPullSweep.z\_ivarname](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.z_ivarname.md)
      * [keysight.pwdatatools.LoadPullSweep.replace](../loadpull/loadpullsweep/_autosummary/keysight.pwdatatools.LoadPullSweep.replace.md)
    - [Grid](../loadpull/grid/index.md)
      * [keysight.pwdatatools.Grid.coord\_system](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.coord_system.md)
      * [keysight.pwdatatools.Grid.extents](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.extents.md)
      * [keysight.pwdatatools.Grid.npointsx](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.npointsx.md)
      * [keysight.pwdatatools.Grid.npointsy](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.npointsy.md)
      * [keysight.pwdatatools.Grid.x\_unique](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.x_unique.md)
      * [keysight.pwdatatools.Grid.y\_unique](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.y_unique.md)
      * [keysight.pwdatatools.Grid.apply](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.apply.md)
      * [keysight.pwdatatools.Grid.drop\_edges](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.drop_edges.md)
      * [keysight.pwdatatools.Grid.includes\_pole](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.includes_pole.md)
      * [keysight.pwdatatools.Grid.from\_gridded\_series](../loadpull/grid/_autosummary/keysight.pwdatatools.Grid.from_gridded_series.md)
  + [Public Submodules](../public_submodules/index.md)
    - [calc](../public_submodules/calc/index.md)
      * [keysight.pwdatatools.calc.db\_to\_power](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.db_to_power.md)
      * [keysight.pwdatatools.calc.db\_to\_voltage](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.db_to_voltage.md)
      * [keysight.pwdatatools.calc.dbm\_to\_w](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.dbm_to_w.md)
      * [keysight.pwdatatools.calc.deg\_to\_rad](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.deg_to_rad.md)
      * [keysight.pwdatatools.calc.gamma\_to\_gamma](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.gamma_to_gamma.md)
      * [keysight.pwdatatools.calc.gamma\_to\_z](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.gamma_to_z.md)
      * [keysight.pwdatatools.calc.polar\_to\_rect](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.polar_to_rect.md)
      * [keysight.pwdatatools.calc.power\_to\_db](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.power_to_db.md)
      * [keysight.pwdatatools.calc.rad\_to\_deg](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.rad_to_deg.md)
      * [keysight.pwdatatools.calc.rect\_to\_polar](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.rect_to_polar.md)
      * [keysight.pwdatatools.calc.voltage\_to\_db](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.voltage_to_db.md)
      * [keysight.pwdatatools.calc.w\_to\_dbm](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.w_to_dbm.md)
      * [keysight.pwdatatools.calc.z\_to\_gamma](../public_submodules/calc/_autosummary/keysight.pwdatatools.calc.z_to_gamma.md)
    - [datatypes](../public_submodules/datatypes/index.md)
      * [keysight.pwdatatools.datatypes.Boolean](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Boolean.md)
      * [keysight.pwdatatools.datatypes.Complex64](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Complex64.md)
      * [keysight.pwdatatools.datatypes.Complex128](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Complex128.md)
      * [keysight.pwdatatools.datatypes.DataType](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.DataType.md)
      * [keysight.pwdatatools.datatypes.FillValues](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.FillValues.md)
      * [keysight.pwdatatools.datatypes.Float32](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Float32.md)
      * [keysight.pwdatatools.datatypes.Float64](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Float64.md)
      * [keysight.pwdatatools.datatypes.Int8](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Int8.md)
      * [keysight.pwdatatools.datatypes.Int16](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Int16.md)
      * [keysight.pwdatatools.datatypes.Int32](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Int32.md)
      * [keysight.pwdatatools.datatypes.Int64](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Int64.md)
      * [keysight.pwdatatools.datatypes.String](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.String.md)
      * [keysight.pwdatatools.datatypes.UInt8](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.UInt8.md)
      * [keysight.pwdatatools.datatypes.UInt16](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.UInt16.md)
      * [keysight.pwdatatools.datatypes.UInt32](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.UInt32.md)
      * [keysight.pwdatatools.datatypes.UInt64](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.UInt64.md)
      * [keysight.pwdatatools.datatypes.FillValues](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.FillValues.md)
    - [roles](../public_submodules/roles/index.md)
    - [viz](../public_submodules/viz/index.md)
      * [keysight.pwdatatools.viz.complex\_vector\_to\_str\_series](../public_submodules/viz/_autosummary/keysight.pwdatatools.viz.complex_vector_to_str_series.md)
      * [keysight.pwdatatools.viz.contourplot](../public_submodules/viz/_autosummary/keysight.pwdatatools.viz.contourplot.md)
      * [keysight.pwdatatools.viz.draw\_smith\_chart](../public_submodules/viz/_autosummary/keysight.pwdatatools.viz.draw_smith_chart.md)
      * [keysight.pwdatatools.viz.float\_vector\_to\_str\_series](../public_submodules/viz/_autosummary/keysight.pwdatatools.viz.float_vector_to_str_series.md)
      * [keysight.pwdatatools.viz.make\_contour\_levels](../public_submodules/viz/_autosummary/keysight.pwdatatools.viz.make_contour_levels.md)
      * [keysight.pwdatatools.viz.tricontourplot](../public_submodules/viz/_autosummary/keysight.pwdatatools.viz.tricontourplot.md)
      * [keysight.pwdatatools.viz.use\_keysight\_theme](../public_submodules/viz/_autosummary/keysight.pwdatatools.viz.use_keysight_theme.md)
  + [Data Types](../datatypes.md)
    - [Boolean](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Boolean.md)
    - [Complex64](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Complex64.md)
    - [Complex128](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Complex128.md)
    - [DataType](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.DataType.md)
    - [FillValues](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.FillValues.md)
    - [Float32](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Float32.md)
    - [Float64](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Float64.md)
    - [Int8](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Int8.md)
    - [Int16](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Int16.md)
    - [Int32](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Int32.md)
    - [Int64](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.Int64.md)
    - [String](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.String.md)
    - [UInt8](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.UInt8.md)
    - [UInt16](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.UInt16.md)
    - [UInt32](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.UInt32.md)
    - [UInt64](../public_submodules/datatypes/_autosummary/keysight.pwdatatools.datatypes.UInt64.md)
  + [Concatenation Functions](../concat/index.md)
    - [concatenate\_blocks](../concat/concatenate_blocks.md)
    - [concatenate\_loadpullblocks](../concat/concatenate_loadpullblocks.md)
    - [concatenate\_vars](../concat/concatenate_vars.md)
  + [Global Options](../global_options.md)
* [Changelog](../../changelog.md)

# File IO Options[](#file-io-options "Link to this heading")

## Format-Specific Read Options[](#format-specific-read-options "Link to this heading")

*class* ADSReadOptions(*\**, *engine\_pref: Literal['dsdump', 'ads-dataset'] | None = None*)[](#keysight.pwdatatools._file_io.reading.options_ads.ADSReadOptions "Link to this definition")
:   Define options and settings for ADS dataset reading.

    This object is immutable, so its properties cannot be changed after
    instantiation.

    *property* engine\_pref*: Literal['dsdump', 'ads-dataset'] | None*[](#keysight.pwdatatools._file_io.reading.options_ads.ADSReadOptions.engine_pref "Link to this definition")
    :   Return engine preference.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.reading.options_ads.ADSReadOptions.get_formats "Link to this definition")
    :   Return formats supported by this class.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.reading.options_ads.ADSReadOptions.mapping "Link to this definition")
    :   Return a dict of property names to property values.

    replace(*\*\*kwargs*) → [ADSReadOptions](#keysight.pwdatatools._file_io.reading.options_ads.ADSReadOptions "keysight.pwdatatools._file_io.reading.options_ads.ADSReadOptions")[](#keysight.pwdatatools._file_io.reading.options_ads.ADSReadOptions.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

        Parameters:
        :   **engine\_pref** (*Literal[‘dsdump’, ‘ads-dataset’, None]*)

        Returns:
        :   New instance with the specified properties replaced.

        Return type:
        :   [*ADSReadOptions*](#keysight.pwdatatools._file_io.reading.options_ads.ADSReadOptions "keysight.pwdatatools._file_io.reading.options_ads.ADSReadOptions")

*class* CITIReadOptions(*\**, *engine\_pref: Literal['python', 'ads'] | None = None*)[](#keysight.pwdatatools._file_io.reading.options_citi.CITIReadOptions "Link to this definition")
:   Define options and settings for CITIfile reading.

    This object is immutable, so its properties cannot be changed after
    instantiation.

    *property* engine\_pref*: Literal['python', 'ads'] | None*[](#keysight.pwdatatools._file_io.reading.options_citi.CITIReadOptions.engine_pref "Link to this definition")
    :   Return engine preference.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.reading.options_citi.CITIReadOptions.get_formats "Link to this definition")
    :   Return formats supported by this class.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.reading.options_citi.CITIReadOptions.mapping "Link to this definition")
    :   Return a dict of property names to property values.

    replace(*\*\*kwargs*) → [CITIReadOptions](#keysight.pwdatatools._file_io.reading.options_citi.CITIReadOptions "keysight.pwdatatools._file_io.reading.options_citi.CITIReadOptions")[](#keysight.pwdatatools._file_io.reading.options_citi.CITIReadOptions.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

        Parameters:
        :   **engine\_pref** (*Optional[Literal[“python”, “ads”]]*)

        Returns:
        :   New instance with the specified properties replaced.

        Return type:
        :   [*CITIReadOptions*](#keysight.pwdatatools._file_io.reading.options_citi.CITIReadOptions "keysight.pwdatatools._file_io.reading.options_citi.CITIReadOptions")

*class* CSVReadOptions(*\**, *engine\_pref: Literal['pandas'] | None = None*, *pandas\_kwargs: Dict[str, Any] | None = None*)[](#keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions "Link to this definition")
:   Define options and settings for CSV file reading.

    This object is immutable, so its properties cannot be changed after
    instantiation.

    *property* engine\_pref*: Literal['pandas'] | None*[](#keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions.engine_pref "Link to this definition")
    :   Return engine preference.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions.get_formats "Link to this definition")
    :   Return formats supported by this class.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions.mapping "Link to this definition")
    :   Return a dict of property names to property values.

    *property* pandas\_kwargs*: Dict[str, Any]*[](#keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions.pandas_kwargs "Link to this definition")
    :   Return keyword arguments for pandas read\_csv function.

    replace(*\*\*kwargs*) → [CSVReadOptions](#keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions "keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions")[](#keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

        Parameters:
        :   * **engine\_pref** (*Optional[Literal[“pandas”]]*)
            * **pandas\_kwargs** (*Optional[Dict[str, Any]]*)

        Returns:
        :   New instance with the specified properties replaced.

        Return type:
        :   [*CSVReadOptions*](#keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions "keysight.pwdatatools._file_io.reading.options_csv.CSVReadOptions")

*class* LoadPullReadOptions(*\**, *derived\_vars: [LoadPullDerivedVars](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars "keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars") | None = LoadPullDerivedVars(main={'efficiency.drain', 'distortion.ampm', 'power.available.input', 'gamma.load', 'power.available.source', 'gain.transducer', 'gain.power', 'power.delivered.load', 'power.delivered.input', 'gamma.input', 'efficiency.power-added'}, freq\_enums={'gamma.load', 'gamma.input'}, power\_units='dBm')*, *always\_freq\_suffixed: Iterable[str] = {'gamma.input', 'gamma.load', 'gamma.source', 'impedance.input', 'impedance.load', 'impedance.source', 'wave.enumerated.incident', 'wave.enumerated.reflected'}*, *power\_ivar\_pref: Literal['power.available.input', 'power.available.source', None] = None*, *uniform\_ivars: bool = False*)[](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions "Link to this definition")
:   Define options and settings for LoadPull datafile reading.

    This object is immutable, so its properties cannot be changed after
    instantiation.

    *property* always\_freq\_suffixed*: FrozenRolesSet*[](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions.always_freq_suffixed "Link to this definition")
    :   Roles whose variable anmes always have an explicit frequency suffix.

    *property* derived\_vars*: [LoadPullDerivedVars](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars "keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars")*[](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions.derived_vars "Link to this definition")
    :   Return derived loadpull variables.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions.get_formats "Link to this definition")
    :   Return formats supported by this class.

    *property* power\_ivar\_pref*: Literal['power.available.input', 'power.available.source', None]*[](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions.power_ivar_pref "Link to this definition")
    :   Return power ivar preference.

    replace(*\*\*kwargs*) → [LoadPullReadOptions](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions "keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions")[](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

        Parameters:
        :   * **derived\_vars** (*LoadPullDerivedVars*)
            * **always\_freq\_suffixed** (*Iterable[str]*)
            * **power\_ivar\_pref** (*Union[‘power.available.source’, ‘power.available.input’, None]*)
            * **uniform\_ivars** (*bool*)

        Returns:
        :   New instance with the specified properties replaced.

        Return type:
        :   [*LoadPullReadOptions*](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions "keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions")

    *property* uniform\_ivars*: bool*[](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullReadOptions.uniform_ivars "Link to this definition")
    :   Return whether to make the ivars as uniform as possible.

*class* LoadPullDerivedVars(*\**, *main: Iterable[str] = FrozenRolesSet({'efficiency.drain', 'distortion.ampm', 'power.available.input', 'gamma.load', 'power.available.source', 'gain.transducer', 'gain.power', 'power.delivered.load', 'power.delivered.input', 'gamma.input', 'efficiency.power-added'})*, *freq\_enums: Iterable[str] = FrozenRolesSet({'gamma.load', 'gamma.input'})*, *power\_units: Literal['dBm', 'mW', 'W'] = 'dBm'*)[](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars "Link to this definition")
:   Define loadpull variables to be calculated from A/B Waves.

    This object is immutable, so its properties cannot be changed after
    instantiation.

    Notes

    Some loadpull data file formats contain A/B wave data, which can be
    used to calculate additional “derived” loadpull variables. You can
    control which variables are derived by setting the `main` and
    `freq_enums` attributes.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars.get_formats "Link to this definition")
    :   Return formats supported by this class.

    replace(*\*\*kwargs*) → [LoadPullDerivedVars](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars "keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars")[](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

        Parameters:
        :   **kwargs** – Keyword arguments to replace properties.

        Returns:
        :   New instance with the specified properties replaced.

        Return type:
        :   [*LoadPullDerivedVars*](#keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars "keysight.pwdatatools._file_io.reading.options_loadpull.LoadPullDerivedVars")

*class* MDIFReadOptions(*\**, *engine\_pref: Literal['python', 'ads'] | None = None*)[](#keysight.pwdatatools._file_io.reading.options_mdif.MDIFReadOptions "Link to this definition")
:   Define options and settings for MDIF reading.

    This object is immutable, so its properties cannot be changed after
    instantiation.

    *property* engine\_pref*: Literal['python', 'ads'] | None*[](#keysight.pwdatatools._file_io.reading.options_mdif.MDIFReadOptions.engine_pref "Link to this definition")
    :   Return engine preference.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.reading.options_mdif.MDIFReadOptions.get_formats "Link to this definition")
    :   Return formats supported by this class.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.reading.options_mdif.MDIFReadOptions.mapping "Link to this definition")
    :   Return a dict of property names to property values.

    replace(*\*\*kwargs*) → [MDIFReadOptions](#keysight.pwdatatools._file_io.reading.options_mdif.MDIFReadOptions "keysight.pwdatatools._file_io.reading.options_mdif.MDIFReadOptions")[](#keysight.pwdatatools._file_io.reading.options_mdif.MDIFReadOptions.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

        Parameters:
        :   **engine\_pref** (*Optional[Literal[“python”, “ads”]]*)

        Returns:
        :   New instance with the specified properties replaced.

        Return type:
        :   [*MDIFReadOptions*](#keysight.pwdatatools._file_io.reading.options_mdif.MDIFReadOptions "keysight.pwdatatools._file_io.reading.options_mdif.MDIFReadOptions")

*class* MDMReadOptions(*\**, *iccap\_values\_as\_vars: bool = False*)[](#keysight.pwdatatools._file_io.reading.options_mdm.MDMReadOptions "Link to this definition")
:   Define options and settings for MDM file reading.

    This object is immutable, so its properties cannot be changed after
    instantiation.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.reading.options_mdm.MDMReadOptions.get_formats "Link to this definition")
    :   Return formats supported by this class.

    *property* iccap\_values\_as\_vars*: bool*[](#keysight.pwdatatools._file_io.reading.options_mdm.MDMReadOptions.iccap_values_as_vars "Link to this definition")
    :   Return whether ICCAP\_VALUES are represented as variables.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.reading.options_mdm.MDMReadOptions.mapping "Link to this definition")
    :   Return a dict of property names to property values.

    replace(*\*\*kwargs*) → [MDMReadOptions](#keysight.pwdatatools._file_io.reading.options_mdm.MDMReadOptions "keysight.pwdatatools._file_io.reading.options_mdm.MDMReadOptions")[](#keysight.pwdatatools._file_io.reading.options_mdm.MDMReadOptions.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

        Parameters:
        :   **iccap\_values\_as\_vars** (*bool*)

        Returns:
        :   New instance with the specified properties replaced.

        Return type:
        :   [*MDMReadOptions*](#keysight.pwdatatools._file_io.reading.options_mdm.MDMReadOptions "keysight.pwdatatools._file_io.reading.options_mdm.MDMReadOptions")

*class* SMatrixIOReadOptions(*\**, *engine\_pref: Literal['python', 'ads'] | None = None*, *network\_blockname: str = 'Network'*)[](#keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions "Link to this definition")
:   Define options and settings for SMatrixIO file reading.

    This object is immutable, so its properties cannot be changed after
    instantiation.

    *property* engine\_pref*: Literal['python', 'ads'] | None*[](#keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions.engine_pref "Link to this definition")
    :   Return engine preference.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions.get_formats "Link to this definition")
    :   Return formats supported by this class.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions.mapping "Link to this definition")
    :   Return a dict of property names to property values.

    *property* network\_blockname*: str*[](#keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions.network_blockname "Link to this definition")
    :   Return the network parameters block name.

    replace(*\*\*kwargs*) → [SMatrixIOReadOptions](#keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions "keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions")[](#keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

        Parameters:
        :   * **engine\_pref** (*Optional[Literal[“python”, “ads”]]*)
            * **network\_blockname** (*str*)

        Returns:
        :   New instance with the specified properties replaced.

        Return type:
        :   [*SMatrixIOReadOptions*](#keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions "keysight.pwdatatools._file_io.reading.options_smatrixio.SMatrixIOReadOptions")

*class* TouchstoneReadOptions(*\**, *engine\_pref: Literal['python', 'ads'] | None = None*, *network\_blockname: str = 'Network'*, *noise\_blockname: str = 'Noise'*)[](#keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions "Link to this definition")
:   Define options and settings for Touchstone file reading.

    This object is immutable, so its properties cannot be changed after
    instantiation.

    *property* engine\_pref*: Literal['python', 'ads'] | None*[](#keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions.engine_pref "Link to this definition")
    :   Return engine preference.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions.get_formats "Link to this definition")
    :   Return formats supported by this class.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions.mapping "Link to this definition")
    :   Return a dict of property names to property values.

    *property* network\_blockname*: str*[](#keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions.network_blockname "Link to this definition")
    :   Return the network parameters block name.

    *property* noise\_blockname*: str*[](#keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions.noise_blockname "Link to this definition")
    :   Return noise block name.

    replace(*\*\*kwargs*) → [TouchstoneReadOptions](#keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions "keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions")[](#keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

        Parameters:
        :   * **engine\_pref** (*Optional[Literal[“python”, “ads”]]*)
            * **network\_blockname** (*str*)
            * **noise\_blockname** (*str*)

        Returns:
        :   New instance with the specified properties replaced.

        Return type:
        :   [*TouchstoneReadOptions*](#keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions "keysight.pwdatatools._file_io.reading.options_touchstone.TouchstoneReadOptions")

## Format-Specific Write Options[](#format-specific-write-options "Link to this heading")

*class* ADSWriteInvalid(*boolean: Literal['float\_w\_nan', 'int\_w\_null'] = 'float\_w\_nan'*, *complexfloating: Literal['complex\_w\_nan'] = 'complex\_w\_nan'*, *floating: Literal['float\_w\_nan'] = 'float\_w\_nan'*, *integer: Literal['float\_w\_nan', 'int\_w\_null'] = 'float\_w\_nan'*, *string: Literal['str\_w\_null'] = 'str\_w\_null'*, *nan\_rep: float = nan*, *integer\_null\_rep: int = 99999*, *string\_null\_rep: str = 'null'*)[](#keysight.pwdatatools._file_io.writing.options_ads.ADSWriteInvalid "Link to this definition")
:   Immutable options for writing invalid datapoint(s) to ADS datasets.

    Each of the 5 generic datatypes has one or more available options for
    writing invalid data to ADS datasets. Additionally, there are options
    for NaN and null representations. NaN values only apply to floating
    and complexfloating datatypes. Note that the current implementation
    does not allow for separate definition of NaN for floating and
    complexfloating.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.writing.options_ads.ADSWriteInvalid.get_formats "Link to this definition")
    :   Return all supported formats.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.writing.options_ads.ADSWriteInvalid.mapping "Link to this definition")
    :   Return dictionary mapping of the options.

    replace(*\*\*kwargs*) → [ADSWriteInvalid](#keysight.pwdatatools._file_io.writing.options_ads.ADSWriteInvalid "keysight.pwdatatools._file_io.writing.options_ads.ADSWriteInvalid")[](#keysight.pwdatatools._file_io.writing.options_ads.ADSWriteInvalid.replace "Link to this definition")
    :   Replace property value(s).

        Since all instances of ADSWriteInvalid are immutable, this returns a
        new instance with all property values copied from self, except any
        new value(s) specified as kwarg(s).

        Parameters:
        :   * **boolean** (*{“float\_w\_nan”, “int\_w\_null”}*) – Defaults to `self.boolean`.
            * **complexfloating** (*{“complex\_w\_nan”}*) – Defaults to `self.complexfloating`.
            * **floating** (*{“float\_w\_nan”}*) – Defaults to `self.floating`.
            * **integer** (*{“float\_w\_nan”, “int\_w\_null”}*) – Defaults to `self.integer`.
            * **string** (*{“str\_w\_null”}*) – Defaults to `self.string`.
            * **nan\_rep** (*float*) – Defaults to `self.nan_rep`.
            * **integer\_null\_rep** (*int*) – Defaults to `self.integer_null_rep`.
            * **string\_null\_rep** (*str*) – Defaults to `self.string_null_rep`.

*class* CSVWriteOptions(*\**, *engine\_pref: Literal['pandas'] | None = None*, *pandas\_kwargs: dict[str, Any] | None = None*, *multidim\_pref: Literal['dims', 'default\_ints'] = 'dims'*, *default\_ints: Literal[1, 0] = 1*, *cols\_delim: Tuple[str, str, str] = ('[', ',', ']')*)[](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions "Link to this definition")
:   A class to store immutable options for writing to CSV files.

    *property* cols\_delim*: Tuple[str, str, str]*[](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions.cols_delim "Link to this definition")
    :   Return the cols\_delim attribute.

    *property* default\_ints*: Literal[1, 0]*[](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions.default_ints "Link to this definition")
    :   Return the default\_ints attribute.

    *property* engine\_pref*: Literal['pandas'] | None*[](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions.engine_pref "Link to this definition")
    :   Preference for engine used to write CSV datasets.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions.get_formats "Link to this definition")
    :   Return format name.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions.mapping "Link to this definition")
    :   Return a dictionary mapping of the options.

    *property* multidim\_pref*: Literal['dims', 'default\_ints']*[](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions.multidim_pref "Link to this definition")
    :   Return the multidim\_pref attribute.

    *property* pandas\_kwargs*: Dict[str, Any]*[](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions.pandas_kwargs "Link to this definition")
    :   Keyword arguments to pass to the pandas writer.

    replace(*\*\*kwargs*) → [CSVWriteOptions](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions "keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions")[](#keysight.pwdatatools._file_io.writing.options_csv.CSVWriteOptions.replace "Link to this definition")
    :   Return a new instance with the specified properties replaced.

*class* MDIFWriteInvalid(*boolean: Literal['float\_w\_nan', 'int\_w\_null'] = 'float\_w\_nan'*, *complexfloating: Literal['complex\_w\_nan'] = 'complex\_w\_nan'*, *floating: Literal['float\_w\_nan'] = 'float\_w\_nan'*, *integer: Literal['float\_w\_nan', 'int\_w\_null'] = 'float\_w\_nan'*, *string: Literal['str\_w\_null'] = 'str\_w\_null'*, *nan\_rep: float | str = 'NaN'*, *integer\_null\_rep: int = 99999*, *string\_null\_rep: str = 'null'*)[](#keysight.pwdatatools._file_io.writing.options_mdif.MDIFWriteInvalid "Link to this definition")
:   Immutable options for writing variables with invalid datapoint(s) to MDIF.

    Each of the 5 generic datatypes has one or more available options for
    writing invalid data to MDIFs. Additionally, there are options for
    NaN and null representation in MDIF files. NaN values only apply to
    floating and complexfloating datatypes.

    get\_formats() → Tuple[str, ...][](#keysight.pwdatatools._file_io.writing.options_mdif.MDIFWriteInvalid.get_formats "Link to this definition")
    :   Return supported writeable formats.

    mapping() → Dict[str, Any][](#keysight.pwdatatools._file_io.writing.options_mdif.MDIFWriteInvalid.mapping "Link to this definition")
    :   Return a dictionary mapping of the options.

    replace(*\*\*kwargs*) → [MDIFWriteInvalid](#keysight.pwdatatools._file_io.writing.options_mdif.MDIFWriteInvalid "keysight.pwdatatools._file_io.writing.options_mdif.MDIFWriteInvalid")[](#keysight.pwdatatools._file_io.writing.options_mdif.MDIFWriteInvalid.replace "Link to this definition")
    :   Replace property value(s).

        Since all instances of MDIFWriteInvalid are immutable, this returns a
        new instance with all property values copied from self, except any
        new value(s) specified as kwarg(s).

        Parameters:
        :   * **boolean** (*{“float\_w\_nan”, “int\_w\_null”}*) – Defaults to `self.boolean`.
            * **complexfloating** (*{“complex\_w\_nan”}*) – Defaults to `self.complexfloating`.
            * **floating** (*{“float\_w\_nan”}*) – Defaults to `self.floating`.
            * **integer** (*{“float\_w\_nan”, “int\_w\_null”}*) – Defaults to `self.integer`.
            * **string** (*{“str\_w\_null”}*) – Defaults to `self.string`.
            * **nan\_rep** (*float or str*) – Defaults to `self.nan_rep`.
            * **integer\_null\_rep** (*int*) – Defaults to `self.integer_null_rep`.
            * **string\_null\_rep** (*str*) – Defaults to `self.string_null_rep`.

On this page

[Previous

write\_file](write_file.md)
[Next

File IO Options Defaults](defaults.md)

* © Keysight Technologies 2000-2023
* [Privacy](https://www.keysight.com/in/en/contact/privacy.html)
* [Terms](https://www.keysight.com/in/en/contact/terms-of-use.html)
* [Feedback](https://www.keysight.com/in/en/contact/support/site-feedback.html)

Built with [Sphinx](https://www.sphinx-doc.org/) using
'Rejoice' theme by Keysight

*arrow\_drop\_up*Top